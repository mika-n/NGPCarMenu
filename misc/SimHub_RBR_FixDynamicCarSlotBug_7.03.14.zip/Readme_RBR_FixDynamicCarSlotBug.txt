SimHub 7.03.14 or newer - Richard Burns Rally (RBR) - Fix for the dynamic car slot issue by MIKA-N
---------------------------------------------------------------------------------------------------

The SimHub application can draw custom dashboard gauges on top of a game screen.
Traditionally new cars are installed in RBR using RBRCIT tool while the RBR game 
is closed (ie. while the RBR is running the car list remains the same).

Nowadays there are new kind of RBR installations where cars can be installed 
dynamically while the RBR game is running, so all 100+ cars are available right away 
without closing and re-starting RBR using cars in batch of 8 cars at the time.
RallysimFans.hu (RFS) RBR online tournament plugin uses dynamic car slots.

The default SimHub data reader plugin for RBR has a problem with dynamic use of 
car slots because the SimHub reader understood only those cars installed in slots 0-7
when the RBR game was started. SimHub and custom overlays did not understand when
a car in certain slot was changed dynamically while the RBR game was runnning.

No worries. This ZIP file contains a new fixed version of LFSReader.dll plugin for SimHub
supporting dynamically installed cars at RBR runtime.

This version of SimHub LFSReader supports also BTB stages when RBR has the latest version
of NGPCarMenu plugin installed and SimHub uses this version of LFSReader.dll SimHub for RBR plugin.

INSTALLATION:
- (Optional) Take a backup copy of existing c:\Program Files\SimHub\LFSReader.dll file.
  You can copy or rename the old existing LFSReader.dll file just in case you need to revert
  back to the old version of LFSReader SimHub plugin.

- (Required) Download and unzip the SimHub_RBR_FixDybamicCarSlotBug.zip file to c:\Program Files\SimHub\ application
  folder (or where ever you have installed SimHub) and let the unzip tool to overwrite the existing LFSReader.dll file
  on the SimHub root folder.

- Launch SimHub and custom overlays as usual and start racing in RBR with dynamic car slot support in RallySimFans
  and BTB support for both in RallySimFans (RSF) and RBRTM (Czech) RBR installations.


2021-03. Released to public domain, free of charge, use at your own risk by MIKA-N. 
         Licensed as WTFPL. http://www.wtfpl.net/

NGPCarMenu: https://github.com/mika-n/NGPCarMenu  (recommended plugin for RBR to improve RBR experience)
SimHub:     https://www.simhubdash.com/  (The SimHub application itself. Uses a separate own license, not tied to this fix)
