SimHub 7.03.14 or newer - Richard Burns Rally (RBR) - Fix for the dynamic car slot issue by MIKA-N
---------------------------------------------------------------------------------------------------

The SimHub application can draw custom dashboard gauges on top of a game screen.
Traditionally new cars are installed in RBR using RBRCIT tool while the RBR game 
is closed (ie. while the RBR is running the car list remains the same).

Nowadays there are new kind of RBR installations where cars can be installed 
dynamically while the RBR game is running, so all 100+ cars are available right away 
without closing and re-starting RBR using cars in batch of 8 cars at the time.
RallysimFans.hu (RFS) RBR online tournament plugin uses dynamic car slots.

The default SimHub data reader plugin for RBR has a problem with dynamic use of 
car slots because the SimHub reader understood only those cars installed in slots 0-7
when the RBR game was started. SimHub and custom overlays did not understand when
a car in certain slot was changed dynamically while the RBR game was runnning.

No worries. This ZIP file contains a new fixed version of LFSReader.dll plugin for SimHub
supporting dynamically installed cars at RBR runtime.

This version of SimHub LFSReader supports also BTB stages when RBR has NGPCarMenu 1.17.17 plugin
or newer version installed and FixSimHubCustomMapData=1 option under [Default] section in rbr\Plugins\NGPCarMenu.ini file.

INSTALLATION:
- (Optional) Take a backup copy of existing c:\Program Files\SimHub\LFSReader.dll file.
  You can copy or rename the old existing LFSReader.dll file just in case you need to revert
  back to the old version of LFSReader SimHub plugin.

- (Optional) If you want to use BTB stages and let SimHub to keep track of stage records and split times then
  enable FixSimHubCustomMapData option in RBR NGPCarMenu plugin options (see NGPCarMenu.ini file in RBR plugins folder).

- (Required) Unzip this SimHub_RBR_FixDybamicCarSlotBug.zip file to c:\Program Files\SimHub\ application
  folder and let the unzip tool to overwrite the existing LFSReader.dll file.

- Launch SimHub and custom overlays as usual and start racing in RBR with dynamic car slots!


2021-03. Released to public domain, free of charge, use at your own risk by MIKA-N. 
         Licensed as WTFPL. http://www.wtfpl.net/

NGPCarMenu: https://github.com/mika-n/NGPCarMenu  (recommended plugin for RBR to improve RBR experience)
SimHub:     https://www.simhubdash.com/  (The SimHub application itself. Uses a separate own license, not tied to this fix)
