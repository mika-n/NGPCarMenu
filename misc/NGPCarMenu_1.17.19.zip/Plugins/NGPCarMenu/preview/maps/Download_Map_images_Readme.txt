If you want to see a map preview image of all original tracks 
in RBRTM Shakedown menu then please download the following ZIP 
file and extract it to rbr\plugins\NGPCarMenu\preview\map folder.

The zip file has PNG preview images for all RBR original tracks.
  https://github.com/mika-n/NGPCarMenu/raw/master/misc/maps/NGPCarMenu_OrigMapPreviews.zip


